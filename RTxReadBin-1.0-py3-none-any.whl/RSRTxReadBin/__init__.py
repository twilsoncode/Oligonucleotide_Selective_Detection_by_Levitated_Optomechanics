""" interface to load wfm files of R&S' windows based oscilloscopes.
    :version: 1.0
    :copyright: 2021 by Rohde & Schwarz GMBH & Co. KG
    :license: MIT, see LICENSE for more details.
"""


__version__ = '1.0'

# Main class
from RSRTxReadBin.RTxReadBin import RTxReadBin

